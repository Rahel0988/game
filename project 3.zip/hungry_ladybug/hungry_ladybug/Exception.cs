﻿using ladybug_game;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hungry_ladybug
{
    internal class Exception
    {
        public LadybugException(string message) : base(message);
    }
}
