﻿namespace ladybug_game
{
    internal class Aphids
    {
        public Aphids()
        {
        }

        internal void drawLadybug()
        {
            throw new NotImplementedException();
        }

        internal object aphidsLocation()
        {
            throw new NotImplementedException();
        }
    }
}