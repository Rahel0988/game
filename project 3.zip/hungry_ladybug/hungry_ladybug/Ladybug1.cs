﻿namespace ladybug_game
{
    internal class Ladybug
    {
        internal int x;
        internal int y;

        public Ladybug()
        {
        }

        public int score { get; internal set; }

        internal void Input()
        {
            throw new NotImplementedException();
        }

        internal object drawLadybug()
        {
            throw new NotImplementedException();
        }

        internal void eat(object v, Aphids aphids)
        {
            throw new NotImplementedException();
        }

        internal void moveLadybug()
        {
            throw new NotImplementedException();
        }
    }
}